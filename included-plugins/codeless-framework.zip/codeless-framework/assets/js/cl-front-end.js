/* global cl_builder_global */

(function($) {
	"use strict";
	var CL_FRONT = window.CL_FRONT || {};
	window.CL_FRONT = CL_FRONT;

    $(document).ready(function () {

    

    });

})(jQuery);